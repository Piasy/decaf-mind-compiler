package decaf.tacvm.parser;

import java.util.ArrayList;

public class ParserHelper extends Parser {
//	|	TEMP '=' VTBL '<' IDENT '>'
//	|	JUMP LABEL
//	|	IF '(' TEMP EQU INT_CONST ')' JUMP LABEL
//	|	PUSH TEMP
//	|	POP INT_CONST
//	|	RETURN TEMP
//	|	RETURN
//	|	LABEL ':'
	void UserAction(SemValue $$, SemValue $1, SemValue $2, SemValue $3,
			SemValue $4, SemValue $5, SemValue $6, SemValue $7, SemValue $8) {
		{
			
		}
	}
}
