package decaf.tacvm.parser;

public class Entry {
	public String name;

	public int offset;
}
